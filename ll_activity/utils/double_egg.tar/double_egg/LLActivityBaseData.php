<?php
const Prize_Id_One = 1; //开学礼包一元代金券的ID
const Money_Id_One = 440; //一元代金券的ID
const Prize_Start_Time = '2018-08-27 00:00:00';//开学礼包开始时间
const Prize_End_Time = '2018-09-09 00:00:00';//开学礼包结束时间
const Activity_Start_Time = '2018-08-27 00:00:00'; //活动开始时间
const Activity_End_Time = '2018-09-09 00:00:00';//活动结束时间

const Scratch_Begin_Time ='2018-09-21 00:00:00';//刮奖活动开始时间
const Scractch_End_Time ='2018-09-27 00:00:00';//刮奖活动结束时间

const Excellent_Student_Command = '学霸榜';
const School_Bag_Command='奖学金';
const Prize_Voucher_One = 1;// 不限无门槛奖品
const Voucher_Id_One = 111;// 不限门槛代金券id

/*****双旦活动常量定义*****/
const Broken_Egg_Task = 9;//砸金蛋任务id
//const Double_Activity_Start_Time = '2018-12-24 00:00:00';
//const Double_Activity_End_Time = '2019-01-04 00:00:00';
const Double_Activity_Start_Time = '2018-12-13';
const Double_Activity_End_Time = '2018-12-25';
//const Golden_Ball_Task = array(1,2,3);
const Share_Task_ID = 3;


